//GPGDAT 0x56000064 R/W �˿�G �����ݼĴ���
#define   GPGDAT (*(int *)0x56000064)
//GPBCON 0x56000010 R/W ���ö˿�B ������
#define   GPBCON (*(int *)0x56000010)
//GPBDAT 0x56000014 R/W �˿�B �����ݼĴ���
#define   GPBDAT (*(int *)0x56000014)

void delay(int time)
{
   int i,j;
   for(i=0; i<time; i++)
      for(j=0; j<1000; j++);
}
int main(void)
{
    GPBCON = 0x01;//set GPB0->output 
	GPBDAT = 0x00;//set beep off
	//GPGCON Ĭ��ֵ
	//GPGDAT
	//  xxxx xxxx xxxx xxxx xxxx xxxx xxxx xxxx
	//& 0000 0000 0000 0000 0000 0000 0000 0001
	//============================================
	//  0000 0000 0000 0000 0000 0000 0000 000x
    while(1)
	{
	   if((GPGDAT & 0x01)==0)
	   {
	//  xxxx xxxx xxxx xxxx xxxx xxxx xxxx xxxx		  ��� 0^0 =0 1^1=0 0^1=1 1^0=1
	//^ 0000 0000 0000 0000 0000 0000 0000 0001
	//============================================
	//  xxxx xxxx xxxx xxxx xxxx xxxx xxxx xxxx	      
		  GPBDAT ^= 0x01;//������״̬�л�
	   }
	}

}
