/****************************************************************
 NAME: u2440mon.c
 DESC: u2440mon entry point,menu,download
 HISTORY:
 Mar.25.2002:purnnamu: S3C2400X profile.c is ported for S3C2410X.
 Mar.27.2002:purnnamu: DMA is enabled.
 Apr.01.2002:purnnamu: isDownloadReady flag is added.
 Apr.10.2002:purnnamu: - Selecting menu is available in the waiting loop. 
                         So, isDownloadReady flag gets not needed
                       - UART ch.1 can be selected for the console.
 Aug.20.2002:purnnamu: revision number change 0.2 -> R1.1       
 Sep.03.2002:purnnamu: To remove the power noise in the USB signal, the unused CLKOUT0,1 is disabled.
 ****************************************************************/
#define	GLOBAL_CLK		1

#include <stdlib.h>
#include <string.h>
#include "def.h"
#include "option.h"
#include "2440addr.h"
//#include "2440lib.h"
#include "2440slib.h"
#include "mmu.h"




static void __irq Timer4_ISR(void)
{
        rGPBDAT ^= 1;
		ClearPending(BIT_TIMER4);	
}
void Timer4_init(void)
{
     rTCFG0 = 255<<8;//����Ԥ��Ƶ1Ϊ255��Ƶ
     rTCFG1 = 3<<16;//���ö�ʱ��4Ϊ1/16��  
     rTCNTB4 = 12207;//���ö�ʱ��4��TCNTB4
     rTCON = (1<<22)|(1<<21)|(0<<20);//�Զ�װ�أ��ֶ����¿�����������ʱ��
     rTCON = (1<<22)|(0<<21)|(1<<20);//�Զ�װ�أ��ֶ����¹أ�������ʱ�� 
}
void gpio_init(int val)
{
	rGPBCON = val;
    rGPBCON = 0x1;
    rGPBDAT = 0x0;
} 	
int main(void)
{
  
	register a = 0x12345678;
	gpio_init(a);
	Timer4_init();
    MMU_Init(); 
	//(*((int*)(0x33ffff00+0x58)
    pISR_TIMER4 =  (unsigned int)Timer4_ISR;
	EnableIrq(BIT_TIMER4);
	
   	while(1);
}


