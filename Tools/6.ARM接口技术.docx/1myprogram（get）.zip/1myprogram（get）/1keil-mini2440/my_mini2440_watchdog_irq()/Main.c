/****************************************************************
 NAME: u2440mon.c
 DESC: u2440mon entry point,menu,download
 HISTORY:
 Mar.25.2002:purnnamu: S3C2400X profile.c is ported for S3C2410X.
 Mar.27.2002:purnnamu: DMA is enabled.
 Apr.01.2002:purnnamu: isDownloadReady flag is added.
 Apr.10.2002:purnnamu: - Selecting menu is available in the waiting loop. 
                         So, isDownloadReady flag gets not needed
                       - UART ch.1 can be selected for the console.
 Aug.20.2002:purnnamu: revision number change 0.2 -> R1.1       
 Sep.03.2002:purnnamu: To remove the power noise in the USB signal, the unused CLKOUT0,1 is disabled.
 ****************************************************************/
#define	GLOBAL_CLK		1

#include <stdlib.h>
#include <string.h>
#include "def.h"
#include "option.h"
#include "2440addr.h"
//#include "2440lib.h"
#include "2440slib.h"
#include "mmu.h"




static void __irq Watchdog_ISR(void)
{
        rGPBDAT ^= 1;
		ClearSubPending(BIT_SUB_WDT);	
		ClearPending(BIT_WDT_AC97);
}
void watchdog_init(void)
{
    rWTDAT = 50000000/256/16;//12207
    rWTCNT = 12207;
    rWTCON = (255<<8) | (1<<5) | (0<<3) | (1<<2) | (0<<0);
}
void gpio_init(void)
{
    rGPBCON = 0x1;
    rGPBDAT = 0x0;
} 	
int main(void)
{
	gpio_init();
	watchdog_init();
    MMU_Init(); 
	//(*((int*)(0x33ffff00+0x58)
    pISR_WDT_AC97 =  (unsigned int)Watchdog_ISR;

	EnableIrq(BIT_WDT_AC97);
	EnableSubIrq(BIT_SUB_WDT);
   	while(1);
}


