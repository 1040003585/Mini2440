/****************************************************************
 NAME: u2440mon.c
 DESC: u2440mon entry point,menu,download
 HISTORY:
 Mar.25.2002:purnnamu: S3C2400X profile.c is ported for S3C2410X.
 Mar.27.2002:purnnamu: DMA is enabled.
 Apr.01.2002:purnnamu: isDownloadReady flag is added.
 Apr.10.2002:purnnamu: - Selecting menu is available in the waiting loop. 
                         So, isDownloadReady flag gets not needed
                       - UART ch.1 can be selected for the console.
 Aug.20.2002:purnnamu: revision number change 0.2 -> R1.1       
 Sep.03.2002:purnnamu: To remove the power noise in the USB signal, the unused CLKOUT0,1 is disabled.
 ****************************************************************/
#define	GLOBAL_CLK		1

#include <stdlib.h>
#include <string.h>
#include "def.h"
#include "option.h"
#include "2440addr.h"
//#include "2440lib.h"
#include "2440slib.h"
#include "mmu.h"


#define PCLK1  (50000000)
#define BPS    (9600)
struct _data
{
    char buff[20];
   char len;
}data;
unsigned char RecFlag = 0;
static void __irq Uart0_ISR(void)
{	
	    RecFlag = 1;
		ClearPending(BIT_UART0);
		ClearSubPending(BIT_SUB_RXD0);
}

void uart0_init(void)
{
    rGPHCON = (2<<4) | (2<<6);
    rULCON0 = 0x03;
    rUCON0 = (1<<2)|(1<<0);
    rUBRDIV0 = (unsigned short) (PCLK1/(BPS*16) - 1);
    
}

void Main(void)
{
	

	uart0_init();
    MMU_Init();
    
    
    pISR_UART0 =  (unsigned int)Uart0_ISR;
	EnableIrq(BIT_UART0);
	EnableSubIrq(BIT_SUB_RXD0);
	data.len = 0;
	
   	while(1)
   	{
   	 if(RecFlag==1)
   	 {      
	     data.buff[data.len++]=rURXH0;
	     if(data.len==20)
	     {
	        data.len = 0;
	     }
	     RecFlag = 0;
     }
   	}
}


