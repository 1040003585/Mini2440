/****************************************************************
 NAME: u2440mon.c
 DESC: u2440mon entry point,menu,download
 HISTORY:
 Mar.25.2002:purnnamu: S3C2400X profile.c is ported for S3C2410X.
 Mar.27.2002:purnnamu: DMA is enabled.
 Apr.01.2002:purnnamu: isDownloadReady flag is added.
 Apr.10.2002:purnnamu: - Selecting menu is available in the waiting loop. 
                         So, isDownloadReady flag gets not needed
                       - UART ch.1 can be selected for the console.
 Aug.20.2002:purnnamu: revision number change 0.2 -> R1.1       
 Sep.03.2002:purnnamu: To remove the power noise in the USB signal, the unused CLKOUT0,1 is disabled.
 ****************************************************************/
#define	GLOBAL_CLK		1

#include <stdlib.h>
#include <string.h>
#include "def.h"
#include "option.h"
#include "2440addr.h"
//#include "2440lib.h"
#include "2440slib.h"
#include "mmu.h"

#define PCLK   (50000000)
#define BPS    (115200)

unsigned char buff[20];
char len = 0;

static void __irq Uart0_ISR(void)
{
        char i;
        buff[len++] = rURXH0;
		if(len==20)
		{
		   for(i=0;i<len;i++)
		   {
		      buff[i++]=0x00;
		   }
		   len = 0;
		  
		}
		ClearSubPending(BIT_SUB_RXD0);
		ClearPending(BIT_UART0);	
}
void uart0_init(void)
{
    rGPHCON = (2<<4) | (2<<6);
	rULCON0 = 0x03;
	rUCON0 = (1<<2)|(1<<0);//TX/RX enable->polling mode

	rUBRDIV0 = (PCLK/(BPS*16))-1;
}
	
int main(void)
{

	uart0_init();
    MMU_Init(); 
	//(*((int*)(0x33ffff00+0x58)
    pISR_UART0 =  (unsigned int)Uart0_ISR;
	EnableSubIrq(BIT_SUB_RXD0);
	EnableIrq(BIT_UART0);
	
   	while(1);
}


